// Names: Arad David, Daniel Knafel
// IDs: 206779597, -id-

#ifndef __SUIT_H
#define __SUIT_H

enum Suit { Hearts, Spades, Diamonds, Clubs };

#endif